import sys
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import FuncFormatter


def format_quarter(x, pos=None):
    date = mdates.num2date(x)
    quarter = (date.month - 1) // 3 + 1
    return f'{date.year} Q{quarter}'


project_root_dir = sys.path[-1]
# load csv or xlsx file
data = pd.read_csv(project_root_dir + '/' + 'simulated_motor_data_corrected2' + '.csv')
# data = pd.read_excel(project_root_dir + '/' + 'simulated_motor_data_corrected2' + '.xlsx')

# convert value string to float, and convert time to datetime format
data['value'] = data['value'].apply(lambda x: float(x.replace(',', '.')))
data['time'] = pd.to_datetime(data['time'])

# save the corrected dataframe as a new csv file. you can choose to save it or not by setting the value of save_new_csv.
save_new_csv = 0
if save_new_csv:
    data.to_csv(project_root_dir + '/' + 'to_float_simulated_motor_data.csv', index=False)


# OEE caculation: non-zero value ratio
data['OEE'] = data['value'].apply(lambda x: 1 if x > 0 else 0)

# Applying different dimensions of OEE analysis
aggregations = {
    'D': 'day',
    'W': 'week',
    'M': 'month',
    'Q': 'quarter',
    'Y': 'year'
}

# Plotting
fig, axs = plt.subplots(len(aggregations), 1, figsize=(10, 20))

for i, (freq, label) in enumerate(aggregations.items()):
    # print(freq, label)
    # calculate OEE by different time dimension
    if freq in ['M', 'Q', 'Y']:
        # Set the label for each time period to the beginning
        oee_agg = data.resample(freq, on='time', label='left', closed='left')['OEE'].mean()
    else:
        # for day and week, default setting
        oee_agg = data.resample(freq, on='time')['OEE'].mean()

    if freq == 'Q':
        # for OEE by quarter
        quarter_formatter = FuncFormatter(format_quarter)
        axs[i].xaxis.set_major_locator(mdates.MonthLocator(bymonth=(1, 4, 7, 10)))
        axs[i].xaxis.set_major_formatter(quarter_formatter)
    elif freq == 'Y':
        # for OEE by year
        axs[i].xaxis.set_major_locator(mdates.YearLocator())
        axs[i].xaxis.set_major_formatter(mdates.DateFormatter('%Y'))

    # plot and set label
    axs[i].plot(oee_agg.index, oee_agg, marker='o', linestyle='-')
    axs[i].set_title(f'OEE by {label}')
    axs[i].set_ylim([-0.05, 1.05])
    axs[i].set_ylabel('OEE')
    axs[i].set_xlabel('Time')

# adjust layout and show the plot
# plt.tight_layout()
fig.subplots_adjust(hspace=0.8)  # 调整子图间的垂直间距
savefig = 0
if savefig:
    plt.savefig('oee_plots.png', dpi=300, bbox_inches='tight')

plt.show()

